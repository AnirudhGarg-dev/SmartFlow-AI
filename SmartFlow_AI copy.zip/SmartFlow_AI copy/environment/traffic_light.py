from enum import Enum
from config.settings import YELLOW_SECONDS, ALL_RED_SECONDS, MIN_GREEN_SECONDS, MAX_GREEN_SECONDS

class SignalState(str, Enum):
    NS_GREEN = "NS_GREEN"
    NS_YELLOW = "NS_YELLOW"
    ALL_RED_TO_EW = "ALL_RED_TO_EW"
    EW_GREEN = "EW_GREEN"
    EW_YELLOW = "EW_YELLOW"
    ALL_RED_TO_NS = "ALL_RED_TO_NS"

class TrafficLight:
    def __init__(self):
        self.state = SignalState.NS_GREEN
        self.state_timer = 0.0
        self.green_elapsed = 0.0
        self.pending_phase = None

    @property
    def green_phase(self):
        if self.state in (SignalState.NS_GREEN, SignalState.NS_YELLOW):
            return "NS"
        if self.state in (SignalState.EW_GREEN, SignalState.EW_YELLOW):
            return "EW"
        return None

    @property
    def is_green(self):
        return self.state in (SignalState.NS_GREEN, SignalState.EW_GREEN)

    def request_phase(self, phase):
        if phase not in ("NS", "EW"):
            return
        if phase == self.green_phase or self.state not in (SignalState.NS_GREEN, SignalState.EW_GREEN):
            return
        if self.green_elapsed < MIN_GREEN_SECONDS:
            return
        self.pending_phase = phase
        self.state = SignalState.NS_YELLOW if self.green_phase == "NS" else SignalState.EW_YELLOW
        self.state_timer = 0.0

    def update(self, dt):
        self.state_timer += dt
        if self.state in (SignalState.NS_GREEN, SignalState.EW_GREEN):
            self.green_elapsed += dt
            if self.green_elapsed >= MAX_GREEN_SECONDS:
                self.request_phase("EW" if self.green_phase == "NS" else "NS")
        elif self.state in (SignalState.NS_YELLOW, SignalState.EW_YELLOW):
            if self.state_timer >= YELLOW_SECONDS:
                self.state = SignalState.ALL_RED_TO_EW if self.pending_phase == "EW" else SignalState.ALL_RED_TO_NS
                self.state_timer = 0.0
        elif self.state in (SignalState.ALL_RED_TO_EW, SignalState.ALL_RED_TO_NS):
            if self.state_timer >= ALL_RED_SECONDS:
                self.state = SignalState.EW_GREEN if self.pending_phase == "EW" else SignalState.NS_GREEN
                self.state_timer = 0.0
                self.green_elapsed = 0.0
                self.pending_phase = None

    def force_safe_request(self, phase):
        # Emergency priority still obeys minimum green and yellow/all-red transitions.
        self.request_phase(phase)
