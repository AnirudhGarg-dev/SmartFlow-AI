import csv
import random
from collections import defaultdict

from config.settings import (
    JUNCTION_IDS,
    JUNCTION_POSITIONS,
    NORMAL_ARRIVAL_RATE,
    PEAK_ARRIVAL_RATE,
    QUEUE_CAPACITY,
    LOGS_DIR,
    RESULTS_DIR,
)

from algorithms.astar import astar_route
from environment.vehicle import Vehicle
from environment.traffic_light import TrafficLight
from agents.intelligent_agent import IntelligentAgent
from controllers.fixed_time_controller import FixedTimeController
from emergency.emergency_manager import EmergencyManager


class Intersection:
    def __init__(self, junction_id):
        self.id = junction_id
        self.light = TrafficLight()
        self.queues = {"NS": [], "EW": []}
        self.total_passed = 0

    def queue_lengths(self):
        return len(self.queues["NS"]), len(self.queues["EW"])

    def wait_totals(self):
        return (
            sum(v.waiting_time for v in self.queues["NS"]),
            sum(v.waiting_time for v in self.queues["EW"]),
        )


class TrafficSimulation:
    def __init__(self):
        self.reset()

    def reset(self):
        self.intersections = {j: Intersection(j) for j in JUNCTION_IDS}

        self.mode = "intelligent"
        self.traffic_level = "normal"
        self.sim_time = 0.0
        self.paused = False

        self.agent = IntelligentAgent(depth=3)
        self.fixed = FixedTimeController()
        self.emergency = EmergencyManager()

        self.arrival_acc = defaultdict(float)
        self.decision_timer = 0.0

        self.vehicles = []
        self.transit = []

        self.metrics = {
            "time": [],
            "avg_wait": [],
            "avg_queue": [],
            "throughput": [],
            "emergency_delay": [],
            "total_wait": 0.0,
            "vehicles_passed": 0,
        }

        self.emergency_wait = 0.0
        self.last_decision = {}

        self._ensure_dirs()

    def _ensure_dirs(self):
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        (RESULTS_DIR / "reports").mkdir(parents=True, exist_ok=True)

    def set_controller(self, mode):
        if mode in ("fixed", "intelligent"):
            self.mode = mode

    def set_traffic_level(self, level):
        if level in ("normal", "peak"):
            self.traffic_level = level

    def _axis(self, a, b):
        ax, ay = JUNCTION_POSITIONS[a]
        bx, by = JUNCTION_POSITIONS[b]

        return "EW" if ax != bx else "NS"

    def _unit_vector(self, a, b):
        ax, ay = JUNCTION_POSITIONS[a]
        bx, by = JUNCTION_POSITIONS[b]

        dx = bx - ax
        dy = by - ay

        distance = max(1, (dx * dx + dy * dy) ** 0.5)

        return dx / distance, dy / distance

    def _queue_target(self, vehicle, junction_id, index):
        """
        Position vehicles behind the stop line.

        Newly spawned vehicles approach from the direction
        of their next junction. Vehicles arriving from another
        junction approach from their previous junction.
        """

        if vehicle.previous_junction is None:
            source = junction_id
            destination = vehicle.next_junction
        else:
            source = vehicle.previous_junction
            destination = junction_id

        ux, uy = self._unit_vector(source, destination)

        x, y = JUNCTION_POSITIONS[junction_id]

        return (
            x - ux * (35 + index * 25),
            y - uy * (35 + index * 25),
        )

    def _make_route(self, jid, direction):
        choices = []

        for destination in JUNCTION_IDS:
            if destination == jid:
                continue

            route = astar_route(jid, destination)

            if len(route) > 1 and self._axis(route[0], route[1]) == direction:
                choices.append(route)

        return random.choice(choices) if choices else []

    def _spawn_vehicle(self, jid, direction):
        route = self._make_route(jid, direction)

        if len(route) < 2:
            return

        vehicle = Vehicle(direction=direction)

        vehicle.route = route
        vehicle.route_index = 0
        vehicle.previous_junction = None
        vehicle.next_junction = route[1]
        vehicle.traveling = False
        vehicle.junction_id = jid

        x, y = JUNCTION_POSITIONS[jid]
        ux, uy = self._unit_vector(jid, route[1])

        # Start outside the junction.
        vehicle.x = x - ux * 125
        vehicle.y = y - uy * 125

        vehicle.target_x, vehicle.target_y = self._queue_target(vehicle, jid, 0)

        vehicle.spawned = True

        self.vehicles.append(vehicle)
        self.intersections[jid].queues[direction].append(vehicle)

    def _generate_arrivals(self, dt):
        rate = (
            NORMAL_ARRIVAL_RATE if self.traffic_level == "normal" else PEAK_ARRIVAL_RATE
        )

        for jid, junction in self.intersections.items():
            for direction in ("NS", "EW"):
                key = (jid, direction)
                self.arrival_acc[key] += rate * dt

                while self.arrival_acc[key] >= 1:
                    self.arrival_acc[key] -= 1

                    if len(junction.queues[direction]) < QUEUE_CAPACITY:
                        self._spawn_vehicle(jid, direction)

    def spawn_emergency(self):
        if self.emergency.active:
            return self.emergency.route

        route = self.emergency.spawn("J1", "J4")

        if route and self.emergency.active:
            jid = self.emergency.current_junction
            vehicle = self.emergency.vehicle

            vehicle.route = route[:]
            vehicle.route_index = 0
            vehicle.previous_junction = None
            vehicle.next_junction = route[1]
            vehicle.traveling = False
            vehicle.junction_id = jid
            vehicle.speed = 110

            x, y = JUNCTION_POSITIONS[jid]
            ux, uy = self._unit_vector(jid, route[1])

            vehicle.x = x - ux * 125
            vehicle.y = y - uy * 125

            vehicle.target_x, vehicle.target_y = self._queue_target(vehicle, jid, 0)

            vehicle.spawned = True

            self.vehicles.append(vehicle)

            self.intersections[jid].queues[vehicle.direction].insert(0, vehicle)

        return route

    def _choose_and_request(self, junction):
        emergency_phase = None

        # Give priority to an ambulance waiting at this junction.
        for direction in ("NS", "EW"):
            if any(v.emergency and not v.traveling for v in junction.queues[direction]):
                emergency_phase = direction
                break

        if self.mode == "fixed":
            desired = self.fixed.choose_phase(junction)
        else:
            desired = self.agent.choose_phase(junction, emergency_phase)

        if emergency_phase:
            desired = emergency_phase

        self.last_decision[junction.id] = desired

        if desired != junction.light.green_phase:
            junction.light.request_phase(desired)

    def _release_vehicle(self, junction, direction, vehicle):
        queue = junction.queues[direction]
        queue.remove(vehicle)

        vehicle.traveling = True
        vehicle.junction_id = junction.id
        vehicle.next_junction = vehicle.route[vehicle.route_index + 1]

        destination = vehicle.next_junction

        ux, uy = self._unit_vector(junction.id, destination)

        x, y = JUNCTION_POSITIONS[destination]

        # Stop before the next junction's stop line.
        vehicle.target_x = x - ux * 35
        vehicle.target_y = y - uy * 35

        self.transit.append(vehicle)

    def _move_vehicles(self, dt):
        # Move queued vehicles and release the first vehicle
        # only when its direction has a green signal.
        for junction in self.intersections.values():
            for direction in ("NS", "EW"):
                queue = junction.queues[direction]

                for index, vehicle in enumerate(queue[:]):
                    target = self._queue_target(vehicle, junction.id, index)

                    vehicle.target_x, vehicle.target_y = target

                    allowed = (
                        index == 0
                        and junction.light.is_green
                        and junction.light.green_phase == direction
                    )

                    if allowed:
                        self._release_vehicle(junction, direction, vehicle)
                    else:
                        vehicle.move_towards(dt)
                        vehicle.waiting_time += dt

                        if vehicle.emergency:
                            self.emergency_wait += dt

        # Move vehicles between connected junctions.
        for vehicle in self.transit[:]:
            arrived = vehicle.move_towards(dt)

            if not arrived:
                continue

            self.transit.remove(vehicle)

            previous = vehicle.junction_id
            current = vehicle.next_junction

            vehicle.previous_junction = previous
            vehicle.junction_id = current
            vehicle.route_index += 1
            vehicle.traveling = False

            # Advance the emergency manager at each reached node.
            if vehicle.emergency:
                self.emergency.advance_if_served()

            # Check whether the vehicle reached its destination.
            if vehicle.route_index >= len(vehicle.route) - 1:
                if vehicle in self.vehicles:
                    self.vehicles.remove(vehicle)

                self.metrics["vehicles_passed"] += 1
                self.metrics["total_wait"] += vehicle.waiting_time

                self.intersections[current].total_passed += 1

                if vehicle.emergency:
                    self.emergency_wait = vehicle.waiting_time

                continue

            # Join the next junction's approach queue.
            vehicle.next_junction = vehicle.route[vehicle.route_index + 1]

            # Signal phase is based on the road used to enter
            # this junction.
            vehicle.direction = self._axis(previous, current)

            destination_queue = self.intersections[current].queues[vehicle.direction]

            destination_queue.append(vehicle)

            vehicle.target_x, vehicle.target_y = self._queue_target(
                vehicle,
                current,
                len(destination_queue) - 1,
            )

    def step(self, dt=0.05):
        if self.paused:
            return

        self.sim_time += dt

        self._generate_arrivals(dt)

        self.decision_timer += dt

        for junction in self.intersections.values():
            junction.light.update(dt)

        if self.decision_timer >= 5:
            self.decision_timer = 0

            for junction in self.intersections.values():
                self._choose_and_request(junction)

        # Animate the A* open and closed lists.
        self.emergency.update_search_animation(dt)

        self._move_vehicles(dt)
        self._record_metrics()

    def _record_metrics(self):
        waiting = [v.waiting_time for v in self.vehicles]

        queues = [
            len(j.queues["NS"]) + len(j.queues["EW"])
            for j in self.intersections.values()
        ]

        self.metrics["time"].append(self.sim_time)

        self.metrics["avg_wait"].append(sum(waiting) / len(waiting) if waiting else 0)

        self.metrics["avg_queue"].append(sum(queues) / len(queues))

        self.metrics["throughput"].append(self.metrics["vehicles_passed"])

        self.metrics["emergency_delay"].append(self.emergency_wait)

    def summary(self):
        return {
            "controller": self.mode,
            "traffic_level": self.traffic_level,
            "simulation_seconds": round(self.sim_time, 1),
            "vehicles_passed": self.metrics["vehicles_passed"],
            "average_waiting_time_seconds": round(
                self.metrics["total_wait"] / max(1, self.metrics["vehicles_passed"]),
                2,
            ),
            "average_queue_length": round(
                sum(self.metrics["avg_queue"]) / max(1, len(self.metrics["avg_queue"])),
                2,
            ),
            "emergency_delay_seconds": round(self.emergency_wait, 2),
        }

    def save_logs(self):
        self._ensure_dirs()

        filename = (
            "fixed_time_results.csv"
            if self.mode == "fixed"
            else "intelligent_results.csv"
        )

        with (LOGS_DIR / filename).open("w", newline="") as f:
            writer = csv.writer(f)

            writer.writerow(
                [
                    "time",
                    "avg_wait",
                    "avg_queue",
                    "throughput",
                    "emergency_delay",
                ]
            )

            writer.writerows(
                zip(
                    self.metrics["time"],
                    self.metrics["avg_wait"],
                    self.metrics["avg_queue"],
                    self.metrics["throughput"],
                    self.metrics["emergency_delay"],
                )
            )

        with (LOGS_DIR / "emergency_events.csv").open("w", newline="") as f:
            writer = csv.writer(f)

            writer.writerow(
                [
                    "simulation_time",
                    "route",
                    "emergency_delay",
                ]
            )

            writer.writerow(
                [
                    self.sim_time,
                    "->".join(self.emergency.route),
                    self.emergency_wait,
                ]
            )

        with (RESULTS_DIR / "reports" / "performance_summary.txt").open("w") as f:
            f.write("SMARTFLOW AI - SIMULATION SUMMARY\n")
            f.write("=" * 38 + "\n")

            for key, value in self.summary().items():
                f.write(f"{key}: {value}\n")
