from dataclasses import dataclass, field
import itertools
import math

_ids = itertools.count(1)


@dataclass
class Vehicle:
    direction: str
    emergency: bool = False
    id: int = field(default_factory=lambda: next(_ids))
    waiting_time: float = 0.0

    # Screen position and movement
    x: float = 0.0
    y: float = 0.0
    target_x: float = 0.0
    target_y: float = 0.0
    speed: float = 150.0
    moving: bool = False
    spawned: bool = False
    route: list = field(default_factory=list)
    route_index: int = 0

    @property
    def label(self):
        return "AMB" if self.emergency else f"V{self.id}"

    def move_towards(self, dt):
        dx = self.target_x - self.x
        dy = self.target_y - self.y
        distance = math.hypot(dx, dy)

        if distance <= 1:
            self.x = self.target_x
            self.y = self.target_y
            self.moving = False
            return True

        step = min(self.speed * dt, distance)
        self.x += dx / distance * step
        self.y += dy / distance * step
        self.moving = True
        return False
