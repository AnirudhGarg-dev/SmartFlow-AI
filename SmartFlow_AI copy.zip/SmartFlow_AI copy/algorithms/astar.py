import heapq

DEFAULT_GRAPH = {
    "J1": {"J2": 1.0, "J3": 1.0},
    "J2": {"J1": 1.0, "J4": 1.0},
    "J3": {"J1": 1.0, "J4": 1.0},
    "J4": {"J2": 1.0, "J3": 1.0},
}

COORDS = {
    "J1": (0, 0),
    "J2": (1, 0),
    "J3": (0, 1),
    "J4": (1, 1),
}


def heuristic(a, b):
    ax, ay = COORDS[a]
    bx, by = COORDS[b]
    return abs(ax - bx) + abs(ay - by)


def astar_search_detailed(start, goal, graph=None):
    graph = graph or DEFAULT_GRAPH

    if start not in graph or goal not in graph:
        return [], float("inf"), [], []

    frontier = [(heuristic(start, goal), 0.0, start)]
    came_from = {}
    costs = {start: 0.0}
    explored = []
    trace = []

    while frontier:
        _, cost, current = heapq.heappop(frontier)

        if cost != costs.get(current):
            continue
        if current in explored:
            continue

        explored.append(current)

        if current != goal:
            for nxt, edge_cost in sorted(graph[current].items()):
                new_cost = cost + edge_cost

                if new_cost < costs.get(nxt, float("inf")):
                    costs[nxt] = new_cost
                    came_from[nxt] = current
                    priority = new_cost + heuristic(nxt, goal)
                    heapq.heappush(frontier, (priority, new_cost, nxt))

        open_nodes = []
        seen = set()

        for f, g, node in sorted(frontier):
            if node not in explored and node not in seen and g == costs.get(node):
                seen.add(node)
                open_nodes.append(
                    {
                        "node": node,
                        "g": g,
                        "h": heuristic(node, goal),
                        "f": f,
                    }
                )

        trace.append(
            {
                "current": current,
                "g": cost,
                "h": heuristic(current, goal),
                "f": cost + heuristic(current, goal),
                "open_list": open_nodes,
                "closed_list": explored.copy(),
            }
        )

        if current == goal:
            path = [goal]
            while path[-1] in came_from:
                path.append(came_from[path[-1]])
            path.reverse()
            return path, cost, explored, trace

    return [], float("inf"), explored, trace


def astar_search(start, goal, graph=None):
    path, cost, explored, _ = astar_search_detailed(start, goal, graph)
    return path, cost, explored


def astar_route(start, goal, graph=None):
    return astar_search(start, goal, graph)[0]
