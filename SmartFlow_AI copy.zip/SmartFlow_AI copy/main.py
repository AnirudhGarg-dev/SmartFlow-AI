import sys
import subprocess
import pygame
import pygame.surfarray

from pathlib import Path

from config.settings import WIDTH, HEIGHT, FPS, JUNCTION_POSITIONS, GRAPHS_DIR
from environment.traffic_simulation import TrafficSimulation
from environment.traffic_light import SignalState
from analytics.visualization import generate_graphs
from analytics.astar_visualization import draw_astar_panel

BG = (18, 23, 32)
ROAD = (55, 62, 73)
WHITE = (240, 245, 250)
GREEN = (40, 220, 120)
YELLOW = (255, 190, 45)
RED = (240, 65, 75)
BLUE = (65, 165, 255)
ORANGE = (255, 135, 40)
DARK = (25, 30, 40)

graph_mode = False
graph_surfaces = []
graph_names = []
graph_index = 0


def draw_text(screen, font, text, pos, color=WHITE):
    screen.blit(font.render(str(text), True, color), pos)


def load_graphs():
    global graph_surfaces, graph_names, graph_index

    graph_surfaces = []
    graph_names = []

    paths = generate_graphs()

    for path in paths:
        path = Path(path)
        if path.exists():
            try:
                image = pygame.image.load(str(path)).convert()
                graph_surfaces.append(image)
                graph_names.append(path.stem.replace("_", " ").title())
            except pygame.error as error:
                print(f"Could not load {path}: {error}")

    graph_index = 0
    return len(graph_surfaces)


def draw_graph_dashboard(screen, font, small):
    screen.fill(BG)

    draw_text(screen, font, "SMARTFLOW AI | PERFORMANCE DASHBOARD", (25, 20), GREEN)

    draw_text(
        screen,
        small,
        "LEFT / RIGHT: Change graph | V: Return to simulation | ESC: Exit",
        (25, 52),
        YELLOW,
    )

    if not graph_surfaces:
        draw_text(
            screen,
            font,
            "No graphs available. Press G in simulation to generate them.",
            (40, 120),
            WHITE,
        )
        return

    image = graph_surfaces[graph_index]
    name = graph_names[graph_index]

    available_width = WIDTH - 100
    available_height = HEIGHT - 180

    image_rect = image.get_rect()
    scale = min(
        available_width / image_rect.width, available_height / image_rect.height
    )

    new_size = (
        max(1, int(image_rect.width * scale)),
        max(1, int(image_rect.height * scale)),
    )

    scaled_image = pygame.transform.smoothscale(image, new_size)

    x = (WIDTH - new_size[0]) // 2
    y = 105 + (available_height - new_size[1]) // 2

    screen.blit(scaled_image, (x, y))

    draw_text(screen, font, name, (25, HEIGHT - 55), GREEN)

    draw_text(
        screen,
        small,
        f"Graph {graph_index + 1} of {len(graph_surfaces)}",
        (WIDTH - 130, HEIGHT - 55),
        WHITE,
    )


def draw_car(screen, vehicle):
    color = ORANGE if vehicle.emergency else BLUE

    body = pygame.Rect(0, 0, 22, 13)
    body.center = (int(vehicle.x), int(vehicle.y))
    pygame.draw.rect(screen, color, body, border_radius=4)

    window = pygame.Rect(0, 0, 9, 7)
    window.center = body.center
    pygame.draw.rect(screen, (210, 230, 245), window, border_radius=2)

    if vehicle.emergency:
        pygame.draw.line(
            screen,
            WHITE,
            (body.centerx - 4, body.centery),
            (body.centerx + 4, body.centery),
            2,
        )
        pygame.draw.line(
            screen,
            WHITE,
            (body.centerx, body.centery - 4),
            (body.centerx, body.centery + 4),
            2,
        )


def draw_junction(screen, font, sim, jid, center):
    x, y = center

    pygame.draw.rect(screen, ROAD, (x - 95, y - 95, 190, 190))

    for offset in range(-85, 90, 25):
        pygame.draw.line(
            screen, (180, 185, 195), (x + offset, y), (x + offset + 12, y), 1
        )
        pygame.draw.line(
            screen, (180, 185, 195), (x, y + offset), (x, y + offset + 12), 1
        )

    junction = sim.intersections[jid]
    state = junction.light.state

    ns_color = (
        GREEN
        if state == SignalState.NS_GREEN
        else YELLOW if state == SignalState.NS_YELLOW else RED
    )

    ew_color = (
        GREEN
        if state == SignalState.EW_GREEN
        else YELLOW if state == SignalState.EW_YELLOW else RED
    )

    pygame.draw.circle(screen, ns_color, (x - 65, y - 65), 10)
    pygame.draw.circle(screen, ew_color, (x + 65, y + 65), 10)

    draw_text(screen, font, jid, (x - 12, y - 12))
    draw_text(screen, font, f"NS: {len(junction.queues['NS'])}", (x - 85, y - 120))
    draw_text(screen, font, f"EW: {len(junction.queues['EW'])}", (x - 85, y + 105))


def draw_roads(screen):
    positions = JUNCTION_POSITIONS

    connections = [("J1", "J2"), ("J3", "J4"), ("J1", "J3"), ("J2", "J4")]

    for a, b in connections:
        pygame.draw.line(screen, ROAD, positions[a], positions[b], 32)
        pygame.draw.line(screen, (180, 185, 195), positions[a], positions[b], 2)


def main():
    global graph_mode, graph_index

    pygame.init()

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("SMARTFLOW AI - Intelligent Traffic Control")

    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Arial", 17, bold=True)
    small = pygame.font.SysFont("Arial", 13)

    sim = TrafficSimulation()
    running = True

    while running:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    running = False

                elif graph_mode:
                    if event.key == pygame.K_v:
                        graph_mode = False

                    elif event.key == pygame.K_RIGHT:
                        if graph_surfaces:
                            graph_index = (graph_index + 1) % len(graph_surfaces)

                    elif event.key == pygame.K_LEFT:
                        if graph_surfaces:
                            graph_index = (graph_index - 1) % len(graph_surfaces)

                    elif event.key == pygame.K_g:
                        count = load_graphs()
                        print(f"Loaded {count} graphs.")

                else:
                    if event.key == pygame.K_SPACE:
                        sim.paused = not sim.paused

                    elif event.key == pygame.K_1:
                        sim.set_controller("fixed")

                    elif event.key == pygame.K_2:
                        sim.set_controller("intelligent")

                    elif event.key == pygame.K_n:
                        sim.set_traffic_level("normal")

                    elif event.key == pygame.K_p:
                        sim.set_traffic_level("peak")

                    elif event.key == pygame.K_e:
                        print("A* route:", sim.spawn_emergency())

                    elif event.key == pygame.K_r:
                        sim.reset()

                    elif event.key == pygame.K_g:
                        try:
                            sim.save_logs()
                            count = load_graphs()
                            print(f"Generated and loaded {count} graphs.")

                            if count:
                                graph_mode = True
                            else:
                                print("No graph images were generated.")

                        except Exception as error:
                            print("Graph generation error:", error)

                    elif event.key == pygame.K_v:
                        graph_mode = True

        if graph_mode:
            draw_graph_dashboard(screen, font, small)

        else:
            sim.step(dt)

            screen.fill(BG)
            draw_roads(screen)

            route = sim.emergency.route

            if len(route) > 1:
                for a, b in zip(route, route[1:]):
                    pygame.draw.line(
                        screen, ORANGE, JUNCTION_POSITIONS[a], JUNCTION_POSITIONS[b], 8
                    )

                draw_text(
                    screen, small, "A* ROUTE: " + " -> ".join(route), (25, 78), ORANGE
                )

                draw_text(
                    screen,
                    small,
                    "EXPLORED: " + ", ".join(sim.emergency.explored_junctions),
                    (25, 98),
                )

            for jid, pos in JUNCTION_POSITIONS.items():
                draw_junction(screen, small, sim, jid, pos)

            for vehicle in sim.vehicles:
                draw_car(screen, vehicle)

            draw_text(
                screen,
                font,
                "SMARTFLOW AI | INTELLIGENT TRAFFIC SIGNAL AGENT",
                (25, 18),
            )

            draw_text(
                screen,
                small,
                f"Controller: {sim.mode.upper()} | "
                f"Traffic: {sim.traffic_level.upper()} | "
                f"Time: {sim.sim_time:.1f}s",
                (25, 48),
                GREEN,
            )

            if sim.emergency.route:
                draw_astar_panel(screen, sim)

            stats = sim.summary()

            draw_text(
                screen,
                small,
                f"Passed: {stats['vehicles_passed']} | "
                f"Average wait: {stats['average_waiting_time_seconds']}s | "
                f"Average queue: {stats['average_queue_length']}",
                (25, 675),
            )

            draw_text(
                screen,
                small,
                "1 Fixed | 2 Intelligent | N Normal | P Peak | "
                "E Ambulance | SPACE Pause | G Graphs | "
                "V Dashboard | R Reset | ESC Exit",
                (25, 710),
                YELLOW,
            )

            if sim.paused:
                draw_text(screen, font, "PAUSED", (WIDTH - 110, 20), YELLOW)

        pygame.display.flip()

    try:
        sim.save_logs()
        paths = generate_graphs()
        print("\nPerformance graphs saved:")
        for path in paths:
            print(path)

    except Exception as error:
        print("Graph generation error:", error)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
