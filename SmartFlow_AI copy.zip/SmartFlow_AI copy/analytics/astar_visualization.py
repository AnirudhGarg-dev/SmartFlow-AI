import pygame


def draw_astar_panel(screen, sim):
    """Display the animated A* search process."""

    width, height = screen.get_size()

    panel_width = min(460, width - 40)
    panel_height = 150
    panel_x = (width - panel_width) // 2
    panel_y = (height - panel_height) // 2

    panel = pygame.Surface((panel_width, panel_height), pygame.SRCALPHA)
    panel.fill((12, 20, 34, 242))
    screen.blit(panel, (panel_x, panel_y))

    pygame.draw.rect(
        screen,
        (65, 165, 255),
        (panel_x, panel_y, panel_width, panel_height),
        2,
        border_radius=8,
    )

    title = pygame.font.SysFont("consolas", 16, bold=True)
    font = pygame.font.SysFont("consolas", 12)
    small = pygame.font.SysFont("consolas", 10)

    def write(text, x, y, color=(225, 235, 245), f=font):
        image = f.render(str(text), True, color)
        screen.blit(image, (x, y))

    emergency = sim.emergency
    trace = emergency.search_trace

    left = panel_x + 12
    middle = panel_x + 155
    right = panel_x + 295

    write("A* EMERGENCY ROUTING", left, panel_y + 8, (80, 190, 255), title)

    if not trace:
        write("Press E to launch ambulance", left, panel_y + 65)
        return

    # Get the CURRENT animated search step, not the final step.
    step = emergency.get_search_step(emergency.display_step)

    if step is None:
        write("Searching...", left, panel_y + 65)
        return

    # LEFT: Optimal route information
    write("OPTIMAL ROUTE", left, panel_y + 34, (80, 240, 150))

    write(" -> ".join(emergency.route), left, panel_y + 52)

    write(f"Cost: {emergency.route_cost:.2f}", left, panel_y + 73)

    write(f"Expanded: {len(step['closed_list'])}", left, panel_y + 92)

    write(
        f"Step: {emergency.display_step + 1}/{emergency.search_steps}",
        left,
        panel_y + 111,
    )

    # MIDDLE: Current node and evaluation values
    write("SEARCH DETAILS", middle, panel_y + 34, (255, 205, 90))

    write(f"Node: {step['current']}", middle, panel_y + 54)

    write(f"g(n): {step['g']:.2f}", middle, panel_y + 75)

    write(f"h(n): {step['h']:.2f}", middle, panel_y + 94)

    write(f"f(n): {step['f']:.2f}", middle, panel_y + 113)

    # RIGHT: Open list
    write("OPEN", right, panel_y + 34, (90, 190, 255))

    open_nodes = step["open_list"]

    if open_nodes:
        for i, node in enumerate(open_nodes[:3]):
            write(
                f"{node['node']} f:{node['f']:.1f}",
                right,
                panel_y + 53 + i * 17,
                f=small,
            )
    else:
        write("Empty", right, panel_y + 54, f=small)

    # RIGHT: Closed list
    write("CLOSED", right, panel_y + 111, (255, 170, 100))

    closed = ", ".join(step["closed_list"])

    write(closed[:28] if closed else "Empty", right, panel_y + 128, f=small)
