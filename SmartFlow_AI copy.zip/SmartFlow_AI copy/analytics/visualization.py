import csv
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config.settings import GRAPHS_DIR, LOGS_DIR

def _read_csv(path):
    if not path.exists():
        return []
    with path.open(newline="") as f:
        return list(csv.DictReader(f))

def generate_graphs():
    GRAPHS_DIR.mkdir(parents=True, exist_ok=True)
    fixed = _read_csv(LOGS_DIR / "fixed_time_results.csv")
    intelligent = _read_csv(LOGS_DIR / "intelligent_results.csv")
    datasets = [
        ("avg_wait", "Average waiting time (s)", "waiting_time_comparison.png"),
        ("avg_queue", "Average queue length", "queue_length_comparison.png"),
        ("throughput", "Vehicles passed", "throughput_comparison.png"),
        ("emergency_delay", "Emergency delay (s)", "emergency_delay_comparison.png"),
    ]
    made = []
    for key, ylabel, filename in datasets:
        plt.figure(figsize=(8, 4.5))
        for rows, label in ((fixed, "Fixed-time"), (intelligent, "Intelligent")):
            if rows:
                xs = [float(r["time"]) for r in rows]
                ys = [float(r[key]) for r in rows]
                plt.plot(xs, ys, label=label)
        plt.xlabel("Simulation time (s)")
        plt.ylabel(ylabel)
        plt.title(ylabel + " comparison")
        plt.grid(True, alpha=0.3)
        if fixed or intelligent:
            plt.legend()
        plt.tight_layout()
        out = GRAPHS_DIR / filename
        plt.savefig(out, dpi=150)
        plt.close()
        made.append(out)
    # Traffic-density graph based on the average queue series.
    plt.figure(figsize=(8, 4.5))
    for rows, label in ((fixed, "Fixed-time"), (intelligent, "Intelligent")):
        if rows:
            plt.plot([float(r["time"]) for r in rows],
                     [float(r["avg_queue"]) for r in rows], label=label)
    plt.xlabel("Simulation time (s)")
    plt.ylabel("Average vehicles queued")
    plt.title("Traffic density / congestion comparison")
    plt.grid(True, alpha=0.3)
    if fixed or intelligent:
        plt.legend()
    plt.tight_layout()
    out = GRAPHS_DIR / "traffic_density_comparison.png"
    plt.savefig(out, dpi=150)
    plt.close()
    made.append(out)
    return made
