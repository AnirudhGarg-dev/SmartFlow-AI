
class FixedTimeController:

    def __init__(self, green_duration=15.0):
        self.green_duration = green_duration
        self.elapsed = 0.0
        self.last_phase = None

    def choose_phase(self, intersection):
        current = intersection.light.green_phase or "NS"

        if self.last_phase != current:
            self.last_phase = current
            self.elapsed = 0.0

        # Called every 5 simulated seconds.
        self.elapsed += 5.0

        if self.elapsed >= self.green_duration:
            self.elapsed = 0.0

            next_phase = "EW" if current == "NS" else "NS"

            self.last_phase = next_phase
            return next_phase

        return current
