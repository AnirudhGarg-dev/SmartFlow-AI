from itertools import product
from agents.utility_function import utility


class IntelligentAgent:
    """Depth-limited search for the best traffic signal phase."""

    def __init__(self, depth=3):
        self.depth = max(1, depth)

    def choose_phase(self, intersection, emergency_phase=None):
        nsq, ewq = intersection.queue_lengths()
        nsw, eww = intersection.wait_totals()

        current = intersection.light.green_phase or "NS"

        # Give emergency vehicles immediate priority.
        if emergency_phase in ("NS", "EW"):
            return emergency_phase

        best_phase = current
        best_score = float("-inf")

        # Explore all possible NS/EW phase sequences.
        for sequence in product(("NS", "EW"), repeat=self.depth):
            qns = float(nsq)
            qew = float(ewq)
            wait_ns = float(nsw)
            wait_ew = float(eww)
            score = 0.0

            for step, phase in enumerate(sequence):
                score += (0.72**step) * utility(
                    qns,
                    qew,
                    wait_ns,
                    wait_ew,
                    phase,
                    emergency_phase=emergency_phase,
                    switch_penalty=(2.0 if phase != current else 0.0),
                )

                # Estimate vehicles served and new arrivals.
                if phase == "NS":
                    qns = max(0.0, qns - 2.0)
                    qew += 0.5
                else:
                    qew = max(0.0, qew - 2.0)
                    qns += 0.5

                # Approximate additional waiting.
                wait_ns += qns
                wait_ew += qew

            if score > best_score:
                best_score = score
                best_phase = sequence[0]

        # Rule-based guard for a heavily congested approach.
        if max(nsq, ewq) >= 8 and abs(nsq - ewq) >= 3:
            return "NS" if nsq > ewq else "EW"

        return best_phase
