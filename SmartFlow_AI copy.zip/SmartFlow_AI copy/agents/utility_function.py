def utility(
    ns_queue,
    ew_queue,
    ns_wait,
    ew_wait,
    phase,
    emergency_phase=None,
    switch_penalty=2.0,
):
    """
    Higher score means a better signal phase.

    Considers:
    - Queue length
    - Waiting time
    - Vehicles left waiting
    - Signal switching penalty
    - Emergency priority
    """

    if phase == "NS":
        served_queue = ns_queue
        served_wait = ns_wait
        waiting_queue = ew_queue
        waiting_time = ew_wait
    else:
        served_queue = ew_queue
        served_wait = ew_wait
        waiting_queue = ns_queue
        waiting_time = ns_wait

    score = (
        1.8 * served_queue
        + 0.08 * served_wait
        - 0.65 * waiting_queue
        - 0.035 * waiting_time
    )

    if emergency_phase is not None:
        if phase == emergency_phase:
            score += 1000.0
        else:
            score -= 1000.0

    return score - switch_penalty
