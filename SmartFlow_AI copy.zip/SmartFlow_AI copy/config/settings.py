from pathlib import Path

# Project directories
BASE_DIR = Path(__file__).resolve().parent.parent
RESULTS_DIR = BASE_DIR / "results"
LOGS_DIR = RESULTS_DIR / "simulation_logs"

GRAPHS_DIR = RESULTS_DIR / "graphs"

REPORTS_DIR = RESULTS_DIR / "reports"

# Window settings
WIDTH = 1100
HEIGHT = 750
FPS = 60

# Junctions
JUNCTION_IDS = ["J1", "J2", "J3", "J4"]

JUNCTION_POSITIONS = {
    "J1": (300, 200),
    "J2": (800, 200),
    "J3": (300, 550),
    "J4": (800, 550),
}

# Traffic arrival rates (vehicles per simulated second)
NORMAL_ARRIVAL_RATE = 0.12
PEAK_ARRIVAL_RATE = 0.30

# Vehicle movement
VEHICLE_PASS_RATE = 0.8

# Traffic light timing (seconds)
YELLOW_SECONDS = 2
ALL_RED_SECONDS = 1
MIN_GREEN_SECONDS = 5
MAX_GREEN_SECONDS = 30

# Simulation settings
DECISION_INTERVAL = 5
QUEUE_CAPACITY = 8
GREEN_DURATION = 10
