# SmartFlow AI – Intelligent Traffic Signal Agent

An intelligent traffic signal simulation system developed
using Python and Pygame.

## Project Overview

SmartFlow AI aims to reduce traffic congestion using
intelligent traffic signal control.

The project simulates multiple road junctions, vehicles,
traffic signals, emergency vehicle priority, and A\*
pathfinding for emergency routing.

## Features

- Multiple connected traffic junctions
- Vehicle generation and movement
- Fixed-time traffic signal controller
- Intelligent traffic signal agent
- Utility-based decision making
- Normal and peak traffic conditions
- Emergency vehicle priority
- A\* emergency vehicle route planning
- Animated A\* search visualization
- Performance graphs and controller comparison

## Technologies

- Python 3.11
- Pygame
- Matplotlib
- A\* Search Algorithm
- CSV

## Project Structure

- main.py: Main application
- config/: Project configuration
- environment/: Traffic simulation
- agents/: Intelligent agent and utility
- controllers/: Fixed-time controller
- algorithms/: A\* pathfinding
- emergency/: Emergency management
- analytics/: Graphs and visualization
- docs/: Project report

## Requirements

- Python 3.11
- pip
- Git

## Installation

### 1. Clone the repository

git clone https://github.com/YOUR_USERNAME/SmartFlow-AI.git

### 2. Open the project folder

cd SmartFlow-AI

### 3. Create a virtual environment

Mac/Linux:

python3.11 -m venv venv

Windows:

py -3.11 -m venv venv

### 4. Activate the environment

Mac/Linux:

source venv/bin/activate

Windows PowerShell:

.\venv\Scripts\Activate.ps1

Windows Command Prompt:

venv\Scripts\activate.bat

### 5. Install dependencies

python -m pip install --upgrade pip

pip install -r requirements.txt

### 6. Run the application

python main.py

## Keyboard Controls

| Key   | Action                  |
| ----- | ----------------------- |
| 1     | Fixed-time controller   |
| 2     | Intelligent controller  |
| N     | Normal traffic          |
| P     | Peak traffic            |
| E     | Spawn emergency vehicle |
| R     | Reset simulation        |
| SPACE | Pause/resume            |
| G     | Generate/display graphs |
| V     | Switch dashboard        |
| ESC   | Exit                    |

## Project Documentation

See docs/SmartFlow_AI_Project_Report.docx

## Team Contributions

Add team member names and their contributions here.

## License

See LICENSE.
