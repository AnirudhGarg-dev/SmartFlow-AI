from algorithms.astar import astar_search_detailed
from environment.vehicle import Vehicle


class EmergencyManager:

    def __init__(self):
        self.active = False
        self.route = []
        self.route_index = 0
        self.vehicle = None
        self.destination = None

        self.route_cost = 0.0
        self.explored_junctions = []

        self.search_trace = []
        self.open_list = []
        self.closed_list = []
        self.search_steps = 0
        self.path_found = False

        self.display_step = 0
        self.animation_timer = 0.0
        self.animation_speed = 0.8

    @staticmethod
    def get_direction(current, next_junction):
        if current in ("J1", "J2") and next_junction in ("J1", "J2"):
            return "EW"

        if current in ("J3", "J4") and next_junction in ("J3", "J4"):
            return "EW"

        return "NS"

    @property
    def current_junction(self):
        if self.active and self.route_index < len(self.route) - 1:
            return self.route[self.route_index]
        return None

    @property
    def current_direction(self):
        if self.current_junction is None:
            return None

        next_junction = self.route[self.route_index + 1]

        return self.get_direction(self.current_junction, next_junction)

    def spawn(self, start="J1", destination="J4"):

        (
            self.route,
            self.route_cost,
            self.explored_junctions,
            self.search_trace,
        ) = astar_search_detailed(start, destination)

        self.route_index = 0
        self.destination = destination
        self.vehicle = None

        self.path_found = bool(self.route)
        self.search_steps = len(self.search_trace)

        self.display_step = 0
        self.animation_timer = 0.0

        self.open_list = []
        self.closed_list = []

        if self.search_trace:
            first_step = self.search_trace[0]
            self.open_list = first_step["open_list"]
            self.closed_list = first_step["closed_list"]

        self.active = self.path_found and len(self.route) > 1

        if self.active:
            self.vehicle = Vehicle(direction=self.current_direction, emergency=True)

        return self.route

    def update_search_animation(self, dt):
        if not self.search_trace:
            return

        if self.display_step >= len(self.search_trace) - 1:
            return

        self.animation_timer += dt

        while (
            self.animation_timer >= self.animation_speed
            and self.display_step < len(self.search_trace) - 1
        ):
            self.animation_timer -= self.animation_speed
            self.display_step += 1

        step = self.search_trace[self.display_step]

        self.open_list = step["open_list"]
        self.closed_list = step["closed_list"]

    def get_search_step(self, index):
        if 0 <= index < len(self.search_trace):
            return self.search_trace[index]
        return None

    def advance_if_served(self):
        """Call when the ambulance reaches its next junction."""

        if not self.active:
            return

        self.route_index += 1

        if self.route_index >= len(self.route) - 1:
            self.active = False
            self.vehicle = None
