from algorithms.astar import astar_search

start = "J1"
goal = "J4"

path, cost, explored = astar_search(start, goal)

print("\n===== SMARTFLOW AI: A* ROUTE FINDER =====")
print("Starting Junction:", start)
print("Destination:", goal)
print("Selected Route:", " -> ".join(path))
print("Total Route Cost:", cost)
print("Explored Junctions:", explored)
print("========================================")